# Trident Viewer rebrand kit (for phoenix-firestorm)

## What it does
Run `apply_trident.py` on a fresh clone and it will:
- Replace the login logo, startup/loading image and first-login image with your moonlit beach scene and the Trident logo.
- Replace all viewer icons (png, ico, bmp, icns) with the cleaned Trident logo.
- Add a **Trident** skin (copy of StarLight, recoloured to black, royal blue and gold) and make it the default skin.
- Rename the viewer to "Trident Viewer" (APP_NAME and the About/Credits menu labels).

Links to Firestorm's own blog, wiki and support group keep their labels, because they still point to Firestorm services.

## Steps
1. Install Python 3 and Pillow: `pip install pillow`
2. Clone the source: `git clone https://github.com/FirestormViewer/phoenix-firestorm.git`
3. Apply the kit: `python apply_trident.py path/to/phoenix-firestorm`
4. Build with Firestorm's normal process (Windows needs Visual Studio, Python, Cygwin and autobuild; see the Firestorm wiki "Compiling the viewer"), and pass your own channel name, for example `--chan "Trident"`.
5. Test the build by logging in, then check Preferences > Colors/Skins shows Trident.

## Before you distribute
- Keep the LGPL license and make your modified source available.
- Follow Linden Lab's Third-Party Viewer Policy and use a unique channel name.
- Firestorm's FMOD and Havok-related options have their own license rules if you enable them.

## Known limits
- Textures inside the StarLight skin that are orange-tinted bitmaps still have an orange tint in places. Colors defined in colors.xml are recoloured, but bitmap buttons and tabs are not yet.
- I tested the apply script on a fresh clone, but I could not compile or launch the viewer here.
