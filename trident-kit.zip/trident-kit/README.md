# Trident Viewer rebrand kit (for phoenix-firestorm)

## What it does
Run `apply_trident.py` on a fresh clone and it will:
- Replace the login logo, startup/loading image and first-login image with your moonlit beach scene and the Trident logo.
- Replace all viewer icons (png, ico, bmp, icns) with the cleaned Trident logo.
- Add a **Trident** skin (copy of StarLight, recoloured to black, royal blue and gold) and make it the default skin.
- Rename the viewer to "Trident Viewer" (APP_NAME and the About/Credits menu labels).

Links to Firestorm's own blog, wiki and support group keep their labels, because they still point to Firestorm services.

## Steps
1. Install Python 3 and Pillow: `pip install pillow`
2. Clone the source: `git clone https://github.com/FirestormViewer/phoenix-firestorm.git`
3. Apply the kit: `python apply_trident.py path/to/phoenix-firestorm`
4. Build with Firestorm's normal process (Windows needs Visual Studio, Python, Cygwin and autobuild; see the Firestorm wiki "Compiling the viewer"), and pass your own channel name, for example `--chan "Trident"`.
5. Test the build by logging in, then check Preferences > Colors/Skins shows Trident.

## Building on GitHub (no PC needed)
1. Fork https://github.com/FirestormViewer/phoenix-firestorm to your GitHub account.
2. Copy the `trident-kit` folder into the root of your fork, and copy `trident-kit/.github/workflows/build_trident.yml` into the fork's `.github/workflows/` folder.
3. In your fork, open Actions, choose "Build Trident Viewer", and click Run workflow. The first run can take several hours.
4. Download the `trident-viewer-windows` artifact when it finishes.
This workflow uses Firestorm's open-source build configuration (ReleaseFS_open), so it has no FMOD audio or KDU image codec. I wrote it from Firestorm's own workflow but have not been able to run it, so expect to fix a step or two on the first attempt.

## Before you distribute
- Keep the LGPL license and make your modified source available.
- Follow Linden Lab's Third-Party Viewer Policy and use a unique channel name.
- Firestorm's FMOD and Havok-related options have their own license rules if you enable them.

## Known limits
- The script recolors orange bitmaps (tabs, toolbar, arrows) to gold by hue shift. Any orange-looking pixels outside that hue range may remain.
- I tested the apply script on a fresh clone, but I could not compile or launch the viewer here.
