#!/usr/bin/env python3
"""Apply Trident Viewer branding to a fresh clone of phoenix-firestorm.
Usage: python apply_trident.py /path/to/phoenix-firestorm
Safe to re-run. Only touches skins, textures, icons and a few UI strings."""
import re, shutil, sys
from pathlib import Path
from PIL import Image

HERE = Path(__file__).parent
repo = Path(sys.argv[1]).resolve()
nv = repo / "indra" / "newview"
assert nv.is_dir(), f"{nv} not found - pass the phoenix-firestorm repo root"

logo = Image.open(HERE / "assets/trident_logo.png").convert("RGBA")
bg = Image.open(HERE / "assets/background.png").convert("RGB")

def fit(img, size):
    img = img.copy(); img.thumbnail(size, Image.LANCZOS)
    c = Image.new("RGBA", size, (0, 0, 0, 0))
    c.paste(img, ((size[0]-img.width)//2, (size[1]-img.height)//2), img)
    return c

def cover(img, size):
    r = max(size[0]/img.width, size[1]/img.height)
    im = img.resize((round(img.width*r), round(img.height*r)), Image.LANCZOS)
    l, t = (im.width-size[0])//2, (im.height-size[1])//2
    return im.crop((l, t, l+size[0], t+size[1]))

def scene(size, logo_frac):
    base = cover(bg, size).convert("RGBA")
    lg = fit(logo, (int(size[0]*logo_frac),)*2)
    base.alpha_composite(lg, ((size[0]-lg.width)//2, (size[1]-lg.height)//2))
    return base

def over(path, img):
    """Overwrite an existing file only, keeping its format and size."""
    p = Path(path)
    if not p.exists(): return
    ext = p.suffix.lower()
    if ext == ".ico":
        img.save(p, sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
    elif ext == ".bmp":
        img.convert("RGB").save(p, "BMP")
    elif ext in (".jpg", ".jpeg"):
        img.convert("RGB").save(p, quality=92)
    elif ext == ".icns":
        img.save(p, "ICNS")
    else:
        img.save(p)

# 1. Branding images
tex = nv / "skins/default/textures/windows"
over(tex / "login_fs_logo.png", fit(logo, (444, 444)))
over(tex / "startup_logo.png", scene((1024, 1024), 0.55))
over(tex / "first_login_image.jpg", scene((675, 450), 0.6))
for p in list(nv.glob("icons/*/firestorm_*")) + list(nv.glob("res/firestorm_icon*")) \
        + list(nv.glob("res-sdl/firestorm_icon*")) + [nv / "res/icon1.ico"]:
    m = re.search(r"_(\d+)\.", p.name)
    size = int(m.group(1)) if m else 512
    over(p, fit(logo, (size, size)))

# 2. Trident skin = copy of StarLight (dark) recoloured black/blue/gold
src, dst = nv / "skins/starlight", nv / "skins/trident"
if not dst.exists():
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("themes"))
GOLD, BLUE = "1.00 0.80 0.10", "0.10 0.30 0.90"
cx = dst / "colors.xml"
t = cx.read_text(encoding="utf-8")
t = t.replace("1.00 0.549 0.267", GOLD).replace("1 0.549 0.267", GOLD)
t = t.replace("0.749 0.298 0", BLUE)
cx.write_text(t, encoding="utf-8")

sk = nv / "skins/skins.xml"
s = sk.read_text(encoding="utf-8")
if "<string>trident</string>" not in s:
    entry = ("    <map>\n      <key>name</key>\n      <string>Trident</string>\n"
             "      <key>folder</key>\n      <string>trident</string>\n"
             "      <key>themes</key>\n      <array>\n        <map>\n"
             "          <key>name</key>\n          <string>Black Blue Gold</string>\n"
             "          <key>folder</key>\n          <string/>\n        </map>\n"
             "      </array>\n    </map>\n\n")
    s = s.replace("<array>\n", "<array>\n" + entry, 1)
    sk.write_text(s, encoding="utf-8")

st = nv / "app_settings/settings.xml"
t = st.read_text(encoding="utf-8")
t = re.sub(r"(<key>SkinCurrent</key>.*?<key>Value</key>\s*<string>)firestorm(</string>)",
           r"\1trident\2", t, count=1, flags=re.S)
st.write_text(t, encoding="utf-8")

# 3. Visible names
def sub_file(path, fn):
    p = nv / path
    if p.exists():
        p.write_text(fn(p.read_text(encoding="utf-8")), encoding="utf-8")
sub_file("skins/default/xui/en/strings.xml",
         lambda x: x.replace('name="APP_NAME">Firestorm<', 'name="APP_NAME">Trident Viewer<'))
# Only rename the viewer's own name. Menu links to Firestorm's blog, wiki,
# support group, etc. keep their wording because they point at Firestorm services.
attr = re.compile(r'((?:label|title)="(?:About |)[^"]*?)Firestorm( Credits|")')
for f in ("menu_viewer.xml", "floater_about.xml"):
    sub_file(f"skins/default/xui/en/{f}", lambda x: attr.sub(r"\1Trident Viewer\2", x))
print("Trident branding applied to", repo)
